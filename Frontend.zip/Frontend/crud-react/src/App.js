import * as React from "react";
import Navbar from "react-bootstrap/Navbar";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import "bootstrap/dist/css/bootstrap.css";

import { BrowserRouter as Router , Routes, Route, Link } from "react-router-dom";

import EditVehicle from "./components/vehicles/edit.component.js";
import VehicleList from "./components/vehicles/list.component.js";
import CreateVehicle from "./components/vehicles/create.component.js";
import About from "./components/vehicles/about.component.js";

function App() {
  return (<Router>
    <Navbar bg="primary">
      <Container>
        <Link to={"/"} className="navbar-brand text-white">
          Basic Crud App
        </Link>
      </Container>
    </Navbar>

    <Container className="mt-5">
      <Row>
        <Col md={12}>
          <Routes>
            <Route path="/vehicle/create" element={<CreateVehicle />} />
            <Route path="/vehicle/edit/:id" element={<EditVehicle />} />
            <Route path="/about" element={<About />} />
            <Route exact path='/' element={<VehicleList />} />
          </Routes>
        </Col>
      </Row>
    </Container>
  </Router>);
}

export default App;