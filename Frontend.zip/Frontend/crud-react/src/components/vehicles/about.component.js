import React from "react";


function About() {
    return (
        <div class="container">
            <div class="row">
                <h1>À propos de ce projet</h1>

                <br />
                <hr />
                <br />

                <h3>Informations générales</h3>
                <p><strong>Site créer par : </strong>Eric Marin Mejia</p>
                <p><strong>Cours : </strong>420-5H6 MO Applications Web transactionnelles.</p>
                <p><strong>Session : </strong>Automne 2023, Collège Montmorency.</p>
                <p><strong>Dépôt Github du projet : </strong><a href="https://github.com/EricMarinMejia/Laravel-Site-MVC" target="_blank">Laravel-Site-MVC</a></p>
                <br />
                <hr />
                <br />
                

                <h3>Description du site et des fonctionalitées</h3>
                <p>
                    <p>
                        <strong>Véhicules</strong><br />
                        <strong>1) Liste</strong><br />
                            La page des véhicules affiche tous les véhicules qui existent avec leur image. Elle permet de les modifier
                            ou de les supprimer. Cette page contient également un bouton en haut à droite qui permet l'ajout d'un 
                            nouveau véhicule et une barre de recherche en haut à gauche pour chercher selon la plaque d'immatriculation.
                    </p>

                    <p>
                        <strong>2) Recherche de véhicule</strong><br />
                            Il est possible de chercher à l'aide de la barre de recherche n'importe quel véhicule à partir de sa plaque.
                            Une liste s'affiche avec les plaques semblabes trouvés et elle mène à la page de modification du véhicule sélectionné.
                    </p>

                    <p>
                        <strong>3) Ajout</strong><br />
                            Cette page permet d'ajouter un nouveau véhicule pour un utilisateur. Tout les champs sont requis sauf celui de l'image.
                            Si aucune photo n'est fourni, une image générique sera défini par défaut.
                    </p>

                    <p>
                        <strong>4) Modification</strong><br />
                            Cette page permet de modifier les détails d'un véhicule. Seuls les champs modifiés seront affectés.
                    </p>
                
                    <p>
                        <strong>5) Supression</strong><br />
                            Cette fonctionalitée permet de supprimer un véhicule.
                    </p>
                </p>


                <br />
                <hr />
                <br />

                <h3>Comment utiliser le site</h3>
                <p>
                        Nous pouvons commencer par observer la liste de véhicules et leur images. Ensuite, nous pouvons cliquer sur le bouton
                        "modifier" d'un des véhicules pour arriver sur la page de modifications. Vous pouvez ici modifier tous les champs 
                        (à l'exception de l'ID) et même la photo. Une fois sauvegardé, vous retournez sur la page principale. Ensuite, vous
                        pouvez cliquer sur le bouton "supprimer" d'un véhicule pour le supprimer. Une alerte de confirmation apparaitra. Finalement,
                        nous avons dans l'acceuil une barre de recherche qui permet de chercher les véhicules selon la plaque d'immatriculation.
                </p>

                <br />
                <hr />
                <br />

                <h3>Diagramme de la base de données</h3>
                <img src={require("../../img/conception.png")} alt="conception.png" />

                <br />
                <hr />
                <br />

                <h3>Base de données basée sur modèle</h3>
                <a href="https://modelarchive.databases.biz/data_models/car_svc_center/index.html" target="_blank">Voir le modèle complet</a>
                <img src={require("../../img/reference.png")} alt="reference.png" />

            </div>
        </div>
    );
}

export default About;