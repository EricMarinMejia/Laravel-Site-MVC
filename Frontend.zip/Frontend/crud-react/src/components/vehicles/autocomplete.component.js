import React, { useState } from 'react';
import Autosuggest from 'react-autosuggest';
import axios from 'axios';

const Autocomplete = () => {
    const [value, setValue] = useState('');
    const [suggestions, setSuggestions] = useState([]);

    const getSuggestions = async (inputValue) => {
        try {
            const response = await axios.get(`http://localhost:8000/vehicle/autocomplete`, {
                params: {
                    search: inputValue,
                },
            });

            return response.data;
        } catch (error) {
            console.error('Error fetching autocomplete suggestions:', error);
            return [];
        }
    };

    const onSuggestionsFetchRequested = async ({ value }) => {
        const suggestions = await getSuggestions(value);
        setSuggestions(suggestions);
    };

    const onSuggestionsClearRequested = () => {
        setSuggestions([]);
    };

    const onSuggestionSelected = (event, { suggestion }) => {
        console.log(suggestion)
        setValue(suggestion.value)
        window.location.href = `/vehicle/edit/${suggestion.id}`;
        // Prevent the default behavior and stop the event propagation
        event.preventDefault();
        event.stopPropagation();
    };

    const renderSuggestion = (suggestion) => (
        <div>
            {suggestion.value}
        </div>
    );

    const inputProps = {
        placeholder: 'Type to search...',
        value,
        onChange: (_, { newValue }) => setValue(newValue),
    };

    return (
        <Autosuggest
            suggestions={suggestions}
            onSuggestionsFetchRequested={onSuggestionsFetchRequested}
            onSuggestionsClearRequested={onSuggestionsClearRequested}
            onSuggestionSelected={onSuggestionSelected}
            getSuggestionValue={(suggestion) => suggestion.label}
            renderSuggestion={renderSuggestion}
            inputProps={inputProps}
        />
    );
};

export default Autocomplete;
