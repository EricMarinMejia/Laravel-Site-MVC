import React, { useEffect, useState } from "react";
import Form from 'react-bootstrap/Form'
import Button from 'react-bootstrap/Button';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { useNavigate, useParams } from 'react-router-dom'
import axios from 'axios';
import Swal from 'sweetalert2';

export default function EditVehicle() {
  const navigate = useNavigate();

  const { id } = useParams()

  const [user_id, setUserId] = useState(-1)
  const [brand, setBrand] = useState("")
  const [model, setModel] = useState("")
  const [license_plate, setLicensePlate] = useState("")
  const [kilometers, setKilometers] = useState(-1)
  const [image, setImage] = useState(null)
  const [validationError,setValidationError] = useState({})

  useEffect(()=>{
    fetchVehicle()
  },[])

  const fetchVehicle = async () => {
    await axios.get(`http://localhost:8000/api/vehicles/${id}`).then(({data})=>{
      console.log(data)
      const { user_id, brand, model, license_plate, kilometers } = data.data
      setUserId(user_id)
      setBrand(brand)
      setModel(model)
      setLicensePlate(license_plate)
      setKilometers(kilometers)
    }).catch(({response:{data}})=>{
      Swal.fire({
        text:data.message,
        icon:"error"
      })
    })
  }

  const changeHandler = (event) => {
		setImage(event.target.files[0]);
	};

  const updateVehicle = async (e) => {
    e.preventDefault();

    const formData = new FormData()
    formData.append('_method', 'PUT');
    formData.append('user_id', user_id)
    formData.append('brand', brand)
    formData.append('model', model)
    formData.append('license_plate', license_plate)
    formData.append('kilometers', kilometers)
    if(image!==null){
      formData.append('image', image)
    }

    await axios.post(`http://localhost:8000/api/vehicles/${id}`, formData).then(({data})=>{
      Swal.fire({
        icon:"success",
        text:data.message
      })
      navigate("/")
    }).catch(({response})=>{
      if(response.status===422){
        setValidationError(response.data.errors)
      }else{
        Swal.fire({
          text:response.data.message,
          icon:"error"
        })
      }
    })
  }


  return (
    <div className="container">
      <div className="row justify-content-center">
        <div className="col-12 col-sm-12 col-md-6">
          <div className="card">
            <div className="card-body">
              <h4 className="card-title">Mise à jour du véhicule</h4>
              <hr />
              <div className="form-wrapper">
                {
                  Object.keys(validationError).length > 0 && (
                    <div className="row">
                      <div className="col-12">
                        <div className="alert alert-danger">
                          <ul className="mb-0">
                            {
                              Object.entries(validationError).map(([key, value])=>(
                                <li key={key}>{value}</li>   
                              ))
                            }
                          </ul>
                        </div>
                      </div>
                    </div>
                  )
                }
                
                {/* STOPPED EDITING HERE, PRETTY SURE I CAN JUST COPY TEXT FROM CREATE COMPONENT*/}
                <Form onSubmit={updateVehicle}>
                  <Row> 
                      <Col>
                        <Form.Group controlId="user_id">
                            <Form.Label>ID de l'utilisateur</Form.Label>
                            {/* REMOVE VALUE={USER_ID} IF DEFAULT VALUE IN FIELD -1*/}
                            <Form.Control type="number" min="0" value={user_id} onChange={(event)=>{
                              setUserId(event.target.value)
                            }}/>
                        </Form.Group>
                      </Col> 
                  </Row>

                  <Row className="my-3">
                      <Col>
                        <Form.Group controlId="brand">
                            <Form.Label>Marque</Form.Label>
                            <Form.Control type="text" rows={3} value={brand} onChange={(event)=>{
                              setBrand(event.target.value)
                            }}/>
                        </Form.Group>
                      </Col>
                  </Row>

                  <Row className="my-3">
                      <Col>
                        <Form.Group controlId="model">
                            <Form.Label>Modèle</Form.Label>
                            <Form.Control type="text" rows={3} value={model} onChange={(event)=>{
                              setModel(event.target.value)
                            }}/>
                        </Form.Group>
                      </Col>
                  </Row>

                  <Row className="my-3">
                      <Col>
                        <Form.Group controlId="license_plate">
                            <Form.Label>Plaque d'immatriculation</Form.Label>
                            <Form.Control type="text" rows={3} value={license_plate} onChange={(event)=>{
                               setLicensePlate(event.target.value)
                            }}/>
                        </Form.Group>
                      </Col>
                  </Row>

                  <Row className="my-3">
                      <Col>
                        <Form.Group controlId="kilometers">
                            <Form.Label>Kilomètres</Form.Label>
                            <Form.Control type="number" min="0" rows={3} value={kilometers} onChange={(event)=>{
                              setKilometers(event.target.value)
                            }}/>
                        </Form.Group>
                      </Col>
                  </Row>
                  <Row>
                    <Col>
                      <Form.Group controlId="Image" className="mb-3">
                        <Form.Label>Image</Form.Label>
                        <Form.Control type="file" onChange={changeHandler} />
                      </Form.Group>
                    </Col>
                  </Row>
                  <Button variant="primary" className="mt-2" size="lg" block="block" type="submit">
                    Mettre à jour
                  </Button>
                </Form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}